# pern-todo-app

<img src="https://www.freecodecamp.org/news/content/images/size/w2000/2020/03/PERN.png" />

https://www.youtube.com/watch?v=ldYcgPKEZC8
