# Angular_MongoDB_Sample

run both server and client simultaneously with mongo server on
for client run npm install and ng serve
for server npm install and node start
